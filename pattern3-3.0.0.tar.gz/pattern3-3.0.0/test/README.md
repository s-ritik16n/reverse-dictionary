Run the test using your favourite test runner (e.g. nosetests or py.test).

TODO add more here.